create function shobj_description(oid, name) returns text
    stable
    strict
    parallel safe
    language sql
BEGIN ATOMIC
 SELECT pg_shdescription.description
    FROM pg_shdescription
   WHERE ((pg_shdescription.objoid = $1) AND (pg_shdescription.classoid = ( SELECT pg_class.oid
            FROM pg_class
           WHERE ((pg_class.relname = $2) AND (pg_class.relnamespace = ('pg_catalog'::regnamespace)::oid)))));
END;

comment on function shobj_description(oid, name) is 'get description for object id and shared catalog name';

alter function shobj_description(oid, name) owner to fins;

