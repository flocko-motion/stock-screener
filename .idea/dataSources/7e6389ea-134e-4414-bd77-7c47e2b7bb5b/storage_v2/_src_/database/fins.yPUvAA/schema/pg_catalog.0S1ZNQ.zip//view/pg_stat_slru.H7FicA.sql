create view pg_stat_slru
            (name, blks_zeroed, blks_hit, blks_read, blks_written, blks_exists, flushes, truncates, stats_reset) as
SELECT s.name,
       s.blks_zeroed,
       s.blks_hit,
       s.blks_read,
       s.blks_written,
       s.blks_exists,
       s.flushes,
       s.truncates,
       s.stats_reset
FROM pg_stat_get_slru() s(name, blks_zeroed, blks_hit, blks_read, blks_written, blks_exists, flushes, truncates,
                          stats_reset);

alter table pg_stat_slru
    owner to fins;

grant select on pg_stat_slru to public;

